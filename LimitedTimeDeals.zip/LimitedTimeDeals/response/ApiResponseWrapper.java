package LimitedTimeDeals.response;

public class ApiResponseWrapper {
    private int statusCode;
    private String responseMessage;


//    private
}
