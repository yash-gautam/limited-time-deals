package LimitedTimeDeals.service;

import LimitedTimeDeals.model.Deal;

public interface DealService {
    public void addNewDeal(Deal deal);
    public void deleteDeal(Deal deal);
    public void updateDeal();
    public void claimDeal();
}
