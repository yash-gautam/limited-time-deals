package LimitedTimeDeals.service;

import LimitedTimeDeals.model.Deal;
import LimitedTimeDeals.repository.DealRepository;

import java.util.Date;

public class DealServiceImplementor implements DealService {
    private DealRepository dealRepo;

    DealServiceImplementor(DealRepository dealRepository) {
        this.dealRepo = dealRepository;
    }

    @Override
    public void addNewDeal(Deal deal) {
//        Deal deal = new Deal(5, 25.0, "Exciting new deal", new Date());
        dealRepo.save(deal);
    }

    @Override
    public void deleteDeal(int id) {
        if(dealRepo.findById!=null) {
            return;
        }

        dealRepo.deleteById(id);
    }

    @Override
    public void updateDeal() {

    }

    @Override
    public void claimDeal() {

    }
}
