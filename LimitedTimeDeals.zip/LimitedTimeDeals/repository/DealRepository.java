package LimitedTimeDeals.repository;

import LimitedTimeDeals.model.Deal;

public interface DealRepository extends JpaRepository<Deal, Integer> {

}
