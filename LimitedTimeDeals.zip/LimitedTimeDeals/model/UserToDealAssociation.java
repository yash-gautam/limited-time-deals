package LimitedTimeDeals.model;

public class UserToDealAssociation {
    private int id;
    private int userId;
    private int dealId;
}
