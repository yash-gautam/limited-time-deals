package LimitedTimeDeals.model;

import java.util.Date;

public class Deal {
    private int id; // auto incremented
    private int numberOfItems;
    private Double price;
    private String description;
    private Date endTime;
    private Enum status;

    public Deal() {

    }

    public Deal(int numberOfItems, Double price, String description, Date endTime) {
        this.numberOfItems = numberOfItems;
        this.price = price;
        this.description = description;
        this.endTime = endTime;
    }

    private void updateEndTime(Date newDate) {
        setEndTime(newDate);
    }

    private void updatePrice(Double price) {
        setPrice(price);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getNumberOfItems() {
        return numberOfItems;
    }

    public void setNumberOfItems(int numberOfItems) {
        this.numberOfItems = numberOfItems;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }
}
