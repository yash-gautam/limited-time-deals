package LimitedTimeDeals.controller;

import LimitedTimeDeals.model.Deal;
import LimitedTimeDeals.service.DealService;
import LimitedTimeDeals.service.DealServiceImplementor;

import java.util.Date;

public class DealController {
    private DealServiceImplementor dealService;

    DealController(DealServiceImplementor dealService) {
        this.dealService = dealService;
    }

    // ADD new deal
    // ADD not null anotations for all params
    public ApiResponseWrapper addDeal(Double price, int items, String description, Date date) {
        Deal deal = new Deal(items, price, description, date);
        dealService.validateRequestBody() {
            dealService.addNewDeal(deal);
            ApiResponseWrapper apiResponseWrapper = new ApiResponseWrapper();
        } else {
            return error
        };

        return apiResponseWrapper;
    }

    //DELETE DEAL
    public String deleteDeal(int id) {
        dealService.deleteDeal(id);

        return "Deal"
    }

    // UDPATE DEAL

    // AVAIL DEAL
}
